'use strict';
/* Shared by the TV and the phones: the synced clock, a tiny DOM builder, labels, and the tickers. */

// Server time = local time + offset. Each sample times a round trip and assumes the server answered at its midpoint;
// the sample with the shortest round trip has the least room for error, so it wins.
const Clock = {
  offset: 0,
  rtt: null,
  now() { return Date.now() + this.offset; },
  async sync(socket, samples = 6) {
    let best = null;
    for (let i = 0; i < samples; i++) {
      const t0 = Date.now();
      const res = await new Promise(resolve => socket.timeout(2000).emit('clock:ping', t0, (err, r) => resolve(err ? null : r)));
      if (!res) continue;
      const rtt = Date.now() - t0;
      if (!best || rtt < best.rtt) best = { rtt, offset: res.server - (t0 + rtt / 2) };
    }
    if (best) { this.offset = best.offset; this.rtt = best.rtt; }
    return best;
  },
  start(socket) {
    socket.on('connect', () => this.sync(socket));
    setInterval(() => socket.connected && this.sync(socket, 3), 20_000);
  },
};

// h('div', { class: 'x', onclick }, 'text', child): strings always become text nodes, never HTML,
// so names and hints typed by players cannot inject markup.
function h(tag, props, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'style' && typeof v === 'object') {
      for (const [sk, sv] of Object.entries(v)) sk.startsWith('--') ? el.style.setProperty(sk, sv) : (el.style[sk] = sv);
    }
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
    else if (k === 'dataset') Object.assign(el.dataset, v);
    else if (k === 'value') el.value = v;
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const kid of kids.flat(Infinity)) {
    if (kid == null || kid === false) continue;
    el.append(kid instanceof Node ? kid : String(kid));
  }
  return el;
}

const emit = (socket, event, data = {}) => new Promise(resolve =>
  socket.timeout(5000).emit(event, data, (err, res) => resolve(err ? { ok: false, error: 'السيرفر ما رد.' } : res)));

// Team 1 teal with dark text, team 2 red with light text: the same teams as «جلسة»'s other games.
const TEAM = {
  t1: { name: 'الفريق الأول', box: 'bg-teal text-resolve', border: 'border-teal', ring: 'ring-teal' },
  t2: { name: 'الفريق الثاني', box: 'bg-red text-clarity', border: 'border-red', ring: 'ring-red' },
};
const SEAT_LABEL = { t1d: 'المفكّك 1', t1g: 'المرشد 1', t2d: 'المفكّك 2', t2g: 'المرشد 2' };
const WIRE_HEX = { RED: '#D8343F', BLUE: '#3F7FC0', YELLOW: '#F5D758', GREEN: '#5E9E46', WHITE: '#F4EADA', BLACK: '#111111' };
const WIRE_AR = { RED: 'الأحمر', BLUE: 'الأزرق', YELLOW: 'الأصفر', GREEN: 'الأخضر', WHITE: 'الأبيض', BLACK: 'الأسود' };
const MODULE_NAME = { wires: 'وحدة الأسلاك', keypad: 'قفل الكود', switches: 'لوحة المفاتيح' };
const HINT_LABEL = ['أ', 'ب'];
const DEFUSER_STATUS = {
  waiting: ['ينتظر التلميحات', 'bg-surface text-muted'],
  ready: ['جاهز', 'bg-surface text-resolve'],
  racing: ['يفكّك…', 'bg-gold text-resolve'],
  defused: ['فكّها!', 'bg-sage text-resolve'],
  fooled: ['انخدع', 'bg-resolve text-coral'],
  out: ['طلع: 3 ضربات', 'bg-resolve text-coral'],
  beaten: ['سبقه الثاني', 'bg-surface text-muted'],
  exploded: ['بووم', 'bg-resolve text-coral'],
};

const mmss = ms => {
  const s = Math.max(0, Math.ceil(ms / 1000));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
};

// One animation loop drives every clock on the page from the synced server time, so a re-render never resets one:
//   [data-until]  a countdown to that server timestamp
//   [data-go]     3 · 2 · 1 · يلا! toward that server timestamp
//   [data-arm]    stays .locked until that server timestamp
function startTickers() {
  const tick = () => {
    const now = Clock.now();
    for (const el of document.querySelectorAll('[data-until]')) {
      const left = Number(el.dataset.until) - now;
      el.textContent = mmss(left);
      el.classList.toggle('text-coral', left <= 10_000);
    }
    for (const el of document.querySelectorAll('[data-go]')) {
      const left = Number(el.dataset.go) - now;
      const label = left > 0 ? String(Math.ceil(left / 1000)) : 'يلا!';
      if (el.textContent !== label) {
        el.textContent = label;
        el.classList.remove('animate-pop');
        void el.offsetWidth; // restart the pop for each new number
        el.classList.add('animate-pop');
      }
    }
    for (const el of document.querySelectorAll('[data-arm]')) el.classList.toggle('locked', now < Number(el.dataset.arm));
    requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
}

function toast(text, tone = 'error') {
  const el = h('div', {
    class: `fixed left-1/2 top-6 z-50 -translate-x-1/2 rounded-xl px-5 py-3 font-bold shadow-xl animate-pop ${tone === 'error' ? 'bg-red text-clarity' : 'bg-sage text-resolve'}`,
    role: 'status',
  }, text);
  document.body.append(el);
  setTimeout(() => el.remove(), 2600);
}

// The bomb as the TV and the phones draw it: a dark steel case. Only public layout goes in, never the solution.
function bombArt(bomb, { untilTs, big = false } = {}) {
  const body = [];
  if (bomb.type === 'wires') {
    body.push(h('div', { class: 'flex flex-col gap-3' }, bomb.layout.colors.map((c, i) =>
      h('div', { class: 'flex items-center gap-3' },
        h('span', { class: `w-6 font-display text-mutedDk ${big ? 'text-xl' : ''}` }, i + 1),
        h('span', { class: 'wire-bar', style: { background: WIRE_HEX[c], '--w': WIRE_HEX[c] }, title: WIRE_AR[c] })))));
  } else if (bomb.type === 'keypad') {
    body.push(h('div', { class: 'flex justify-center gap-2', dir: 'ltr' }, Array.from({ length: bomb.layout.length }, () =>
      h('span', { class: `grid place-items-center rounded-lg bg-black font-mono font-bold text-coral ${big ? 'h-16 w-12 text-4xl' : 'h-12 w-9 text-2xl'}` }, '_'))));
    body.push(h('div', { class: 'mx-auto grid w-48 grid-cols-3 gap-2', dir: 'ltr' }, ['1', '2', '3', '4', '5', '6', '7', '8', '9', '⌫', '0', '↵'].map(k =>
      h('span', { class: 'grid h-9 place-items-center rounded-md bg-cream font-display font-bold text-ink' }, k))));
  } else {
    body.push(h('div', { class: 'flex justify-center gap-4', dir: 'ltr' }, Array.from({ length: bomb.layout.count }, (_, i) =>
      h('div', { class: 'flex flex-col items-center gap-2' },
        h('span', { class: `relative rounded-full bg-black ring-2 ring-[#57504f] ${big ? 'h-24 w-10' : 'h-16 w-8'}` },
          h('span', { class: `absolute inset-x-1 bottom-1 rounded-full bg-cream ${big ? 'h-10' : 'h-6'}` })),
        h('span', { class: 'font-display text-mutedDk' }, i + 1)))));
  }
  return h('div', { class: 'bomb w-full' },
    h('div', { class: 'flex items-center justify-between gap-4' },
      h('span', { class: `font-display font-bold ${big ? 'text-xl' : ''}` }, MODULE_NAME[bomb.type]),
      h('span', { class: `rounded-lg bg-black px-3 py-1 font-mono font-bold tabular-nums text-coral ${big ? 'text-3xl' : 'text-xl'}`, dir: 'ltr', dataset: untilTs ? { until: untilTs } : {} }, untilTs ? '' : '--:--')),
    body);
}

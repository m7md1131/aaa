'use strict';
/* The phone. One page, three faces: the defuser's pad, the true guide's brief, the saboteur's fragments. */
const socket = io();
const app = document.getElementById('app');
let S = null;
let joinErr = '';
let lastKey = '';
const revealed = new Set(); // rounds whose secret brief this phone has uncovered
// The defuser's input lives here, not on the server, until it is submitted.
const pad = { round: 0, cuts: [], code: '', switches: [], flash: null };

Clock.start(socket);
startTickers();

const saved = () => { try { return JSON.parse(localStorage.getItem('bs.player') || 'null'); } catch { return null; } };

// Reloads and dropped connections rejoin the same seat with the stored player id.
socket.on('connect', async () => {
  const me = saved();
  if (!me) return render(true);
  const res = await emit(socket, 'player:join', me);
  if (!res.ok) { localStorage.removeItem('bs.player'); joinErr = res.error; S = null; render(true); }
});
socket.on('state', s => { S = s; render(); });
socket.on('kicked', msg => { localStorage.removeItem('bs.player'); S = null; joinErr = msg; render(true); });

async function join() {
  const code = document.getElementById('f-code').value.trim().toUpperCase();
  const name = document.getElementById('f-name').value.trim();
  const res = await emit(socket, 'player:join', { code, name });
  if (!res.ok) { joinErr = res.error; return render(true); }
  joinErr = '';
  localStorage.setItem('bs.player', JSON.stringify({ code: res.code, playerId: res.playerId, name }));
  localStorage.setItem('bs.name', name);
}

const act = async (event, data) => { const r = await emit(socket, event, data); if (!r.ok) toast(r.error); return r; };
const teamChip = t => h('span', { class: `chip ${TEAM[t].box}` }, TEAM[t].name);
const timer = ts => h('span', { class: 'font-display text-2xl font-bold tabular-nums', dir: 'ltr', dataset: { until: ts } });

/* ---------------- screens ---------------- */

function joinScreen() {
  const code = new URLSearchParams(location.search).get('code') || saved()?.code || '';
  return [
    h('header', { class: 'flex flex-col items-center gap-2 pt-4 text-center' },
      h('h1', { class: 'font-kufi text-6xl leading-[1.3]' }, 'المخرّب'),
      h('div', { class: 'sadu w-[min(320px,80%)]', 'aria-hidden': 'true' }),
      h('p', { class: 'max-w-[34ch] text-muted' }, 'مفكّكين يتسابقون على قنبلة، ومرشدين واحد منهم يكذب.')),
    h('form', { class: 'panel', onsubmit: e => { e.preventDefault(); join(); } },
      h('h2', { class: 'text-xl' }, 'ادخل الغرفة'),
      h('label', { class: 'label', for: 'f-name' }, 'اسمك'),
      h('input', { id: 'f-name', class: 'field', maxlength: 16, autocomplete: 'nickname', placeholder: 'مثلًا: أبو فهد', value: localStorage.getItem('bs.name') || '', required: true }),
      h('label', { class: 'label', for: 'f-code' }, 'رمز الغرفة (يطلع على التلفزيون)'),
      h('input', { id: 'f-code', class: 'field text-center font-display text-3xl uppercase tracking-[.4em]', dir: 'ltr', maxlength: 4, autocomplete: 'off', autocapitalize: 'characters', placeholder: 'K7QM', value: code, required: true }),
      joinErr ? h('p', { class: 'text-sm font-bold text-red', role: 'alert' }, joinErr) : null,
      h('button', { class: 'btn w-full text-lg', type: 'submit', disabled: !socket.connected }, socket.connected ? 'ادخل' : 'يتصل…')),
  ];
}

function topBar() {
  const you = S.you;
  // A guide's role stays hidden behind the same tap-to-reveal as the brief, so a glance at the phone gives nothing away.
  let chip = null;
  if (you.role === 'defuser') chip = ['المفكّك', 'bg-resolve text-clarity'];
  else if (you.role && S.phase === 'lobby') chip = ['المرشد', 'bg-resolve text-clarity'];
  else if (you.role && (revealed.has(S.round) || S.phase === 'result' || S.phase === 'over')) {
    chip = you.role === 'guide' ? ['المرشد الصادق', 'bg-sage text-resolve'] : ['المخرّب', 'bg-red text-clarity'];
  }
  return h('header', { class: 'flex items-center justify-between gap-2' },
    h('div', { class: 'min-w-0' },
      h('div', { class: 'label' }, 'الغرفة ', h('b', { dir: 'ltr', class: 'tracking-widest' }, S.code), S.round ? ` · الجولة ${S.round} من ${S.rounds}` : ''),
      h('div', { class: 'flex items-center gap-2 text-lg font-bold' }, h('span', { class: 'truncate' }, you.name), you.team ? teamChip(you.team) : null)),
    chip ? h('span', { class: `chip px-4 py-1 text-sm ${chip[1]}` }, chip[0]) : null);
}

function lobbyScreen() {
  const you = S.you;
  const seatBtn = seat => {
    const p = S.seats[seat], mine = you.seat === seat, t = seat.slice(0, 2);
    return h('button', {
      class: `flex flex-col items-start gap-1 rounded-xl p-4 text-start transition ${mine ? `${TEAM[t].box} ring-4 ring-resolve` : p ? 'bg-sunk opacity-60' : 'border-2 border-dashed border-land bg-surface'}`,
      disabled: !!p && !mine, onclick: () => !mine && act('player:seat', { seat }),
    },
    h('span', { class: `text-xs font-bold ${mine ? '' : 'text-muted'}` }, `${TEAM[t].name} · ${SEAT_LABEL[seat].replace(/ \d$/, '')}`),
    h('span', { class: 'font-display text-lg font-bold' }, p ? p.name : 'اضغط واجلس'));
  };
  const seated = Object.values(S.seats).filter(Boolean).length;
  return [
    h('section', { class: 'panel' },
      h('h2', { class: 'text-xl' }, you.seat ? `أنت ${SEAT_LABEL[you.seat]}` : 'اختر كرسيك'),
      h('p', { class: 'text-muted' }, 'المفكّكين يتسابقون من جوالاتهم. المرشدين يكتبون تلميحات، وكل جولة واحد منهم يشتغل بالسر للفريق الثاني.')),
    h('div', { class: 'grid grid-cols-2 gap-3' }, seatBtn('t1d'), seatBtn('t2d'), seatBtn('t1g'), seatBtn('t2g')),
    you.seat ? h('button', { class: 'btn-ghost', onclick: () => act('player:unseat') }, 'قوم من الكرسي') : null,
    h('p', { class: 'text-center text-muted' }, seated < 4 ? `${seated} من 4 جالسين. ننتظر الباقين…` : 'الكراسي كلها مليانة. المضيف يبدأ من التلفزيون.'),
  ];
}

/* ---- guides ---- */

function hintForm(placeholder) {
  const max = S.hintMax;
  const counter = h('span', { class: 'font-display text-sm text-muted', dir: 'ltr' }, `0/${max}`);
  const input = h('textarea', {
    id: 'f-hint', class: 'field min-h-[5.5rem] resize-none text-lg', maxlength: max, placeholder, rows: 3,
    oninput: e => { counter.textContent = `${Array.from(e.target.value).length}/${max}`; },
  });
  const send = async () => {
    const text = input.value;
    if (!text.trim()) return toast('اكتب التلميح أول.');
    const r = await act('guide:hint', { text });
    if (r.ok) toast('انرسل.', 'ok');
  };
  return h('section', { class: 'panel' },
    h('div', { class: 'flex items-center justify-between' }, h('label', { class: 'font-display font-bold text-auth', for: 'f-hint' }, 'تلميحك'), counter),
    input,
    h('p', { class: 'text-sm text-muted' }, 'يطلع على التلفزيون كـ«تلميح أ» أو «تلميح ب»، بنفس شكل الثاني. ما أحد يعرف مين كتب أي واحد.'),
    h('button', { class: 'btn w-full text-lg', onclick: send }, 'أرسل'));
}

function cover() {
  return h('button', {
    class: 'night flex min-h-[18rem] flex-col items-center justify-center gap-3 px-6 pb-6 text-center',
    onclick: () => { revealed.add(S.round); render(true); },
  },
  h('span', { class: 'font-kufi text-5xl leading-[1.4] text-gold' }, 'سرّي'),
  h('span', { class: 'text-mutedDk' }, 'غطّ الشاشة عن اللي جنبك، واضغط عشان تقرا مهمتك.'));
}

function briefCard() {
  const b = S.you.brief;
  return h('section', { class: 'panel border-4 border-sage' },
    h('span', { class: 'chip self-start bg-sage px-4 py-1 text-resolve' }, 'المرشد الصادق · المعلومات كاملة'),
    h('div', {}, h('div', { class: 'label' }, 'الموقع'), h('div', { class: 'font-display text-xl font-bold text-auth' }, b.location)),
    h('p', {}, b.story),
    h('div', { class: 'rounded-xl bg-gold p-4 text-resolve' },
      h('div', { class: 'text-sm text-auth' }, `${MODULE_NAME[b.module]}: خطوات الفك`),
      h('ol', { class: 'mt-1 list-decimal space-y-1 ps-5 font-display text-lg font-bold' }, b.steps.map(s => h('li', {}, s)))));
}

function fragmentsCard() {
  return h('section', { class: 'panel border-4 border-red' },
    h('span', { class: 'chip self-start bg-red px-4 py-1 text-clarity' }, 'المخرّب · كلمات متقطعة بس'),
    h('p', {}, 'التقطت كم كلمة من الإرسال. لا قصة ولا موقع. ركّب منها تلميح مزيّف يبان كأنه الصح.'),
    h('div', { class: 'flex flex-wrap gap-2' }, S.you.keywords.map(k =>
      h('span', { class: 'rounded-lg bg-resolve px-3 py-2 font-display text-lg font-bold text-gold' }, k))),
    h('p', { class: 'text-sm text-muted' }, 'المفكّك اللي ينفذ تلميحك المزيّف يطلع من الجولة، وإذا كان مفكّك الفريق الثاني ياخذ فريقك نقطة.'));
}

function guideScreen() {
  const you = S.you;
  if (S.phase === 'hints' && !revealed.has(S.round)) return [cover()];
  const intel = you.role === 'guide' ? briefCard() : fragmentsCard();
  if (S.phase === 'hints' && you.hint === null) {
    return [
      h('div', { class: 'flex items-center justify-between' }, h('span', { class: 'label' }, 'التلميحات تتقفل بعد'), timer(S.phaseEndsAt)),
      intel,
      hintForm(you.role === 'guide' ? 'مثلًا: لون البحر، بعدها لون الليل' : 'خلّه يبان صادق…'),
    ];
  }
  return [
    h('section', { class: 'panel items-center text-center' },
      h('div', { class: 'label' }, 'أرسلت'),
      h('p', { class: 'break-words font-display text-2xl font-bold text-auth' }, `«${you.hint}»`),
      h('p', { class: 'text-muted' }, S.phase === 'hints' ? `ننتظر المرشد الثاني (${S.hintsIn} من 2)…` : 'طالع التلفزيون. ممنوع الكلام الحين!')),
    S.phase === 'countdown' ? h('div', { class: 'text-center font-kufi text-8xl leading-[1.4] text-auth', dataset: { go: S.goAt } }) : null,
    revealed.has(S.round) ? intel : null,
  ];
}

/* ---- defuser ---- */

function resetPad() {
  pad.round = S.round;
  pad.cuts = [];
  pad.code = '';
  pad.switches = Array(S.bomb?.layout?.count || 5).fill(false);
  pad.flash = null;
}

async function submit(payload) {
  const r = await act('defuser:submit', payload);
  if (!r.ok) return;
  const msg = {
    strike: [`ضربة ${r.strikes} من ${S.maxStrikes}`, 'bg-coral text-resolve', 200],
    out: ['طلعت: 3 ضربات', 'bg-red text-clarity', [300, 100, 300]],
    fooled: ['انخدعت! هذا كان المزيّف.', 'bg-red text-clarity', [500, 100, 500]],
    defused: ['فكّيتها!', 'bg-sage text-resolve', 80],
  }[r.outcome];
  if (navigator.vibrate) navigator.vibrate(msg[2]);
  pad.flash = { text: msg[0], cls: msg[1], until: Date.now() + 1800 };
  pad.cuts = []; pad.code = ''; pad.switches = pad.switches.map(() => false);
  render(true);
  setTimeout(() => render(true), 1900);
}

function wiresPad(live) {
  const colors = S.bomb.layout.colors;
  return [
    h('p', { class: 'text-center text-sm text-mutedDk' }, 'اختر سلكين بالترتيب اللي بتقطعهم فيه.'),
    h('div', { class: 'flex flex-col gap-2' }, colors.map((c, i) => {
      const order = pad.cuts.indexOf(i);
      return h('button', {
        class: `flex items-center gap-3 rounded-xl bg-resolve p-3 ring-2 ${order >= 0 ? 'ring-gold' : 'ring-transparent'}`,
        disabled: !live, 'aria-label': `السلك ${WIRE_AR[c]}`,
        onclick: () => { order >= 0 ? pad.cuts.splice(order, 1) : pad.cuts.length < 2 && pad.cuts.push(i); render(true); },
      },
      h('span', { class: 'w-5 font-display text-mutedDk' }, i + 1),
      h('span', { class: `wire-bar h-5 ${order >= 0 ? 'wire-cut' : ''}`, style: { background: WIRE_HEX[c], '--w': WIRE_HEX[c] } }),
      h('span', { class: 'grid h-8 w-8 place-items-center rounded-full bg-gold font-display font-bold text-resolve', style: { visibility: order >= 0 ? 'visible' : 'hidden' } }, order + 1));
    })),
    h('div', { class: 'grid grid-cols-2 gap-3' },
      h('button', { class: 'btn-ghost', disabled: !live || !pad.cuts.length, onclick: () => { pad.cuts = []; render(true); } }, 'مسح'),
      h('button', { class: 'btn-red text-lg', disabled: !live || pad.cuts.length !== 2, onclick: () => submit({ cuts: pad.cuts.slice() }) }, '✂ اقطع')),
  ];
}

function keypadPad(live) {
  const key = (label, onclick, cls = 'bg-cream text-ink') =>
    h('button', { class: `btn h-16 font-display text-2xl ${cls}`, disabled: !live, onclick }, label);
  const digit = d => key(d, () => { if (pad.code.length < 4) { pad.code += d; render(true); } });
  return [
    h('div', { class: 'flex justify-center gap-2', dir: 'ltr' }, Array.from({ length: 4 }, (_, i) =>
      h('span', { class: 'grid h-16 w-12 place-items-center rounded-lg bg-black font-mono text-4xl font-bold text-coral' }, pad.code[i] || '_'))),
    h('div', { class: 'grid grid-cols-3 gap-2', dir: 'ltr' },
      ['1', '2', '3', '4', '5', '6', '7', '8', '9'].map(digit),
      key('مسح', () => { pad.code = ''; render(true); }, 'bg-land text-resolve text-base'),
      digit('0'),
      h('button', { class: 'btn-gold h-16 text-base', disabled: !live || pad.code.length !== 4, onclick: () => submit({ code: pad.code }) }, 'إدخال')),
  ];
}

function switchesPad(live) {
  return [
    h('p', { class: 'text-center text-sm text-mutedDk' }, 'ظبّط المفاتيح، وبعدين اضغط «تسليح».'),
    h('div', { class: 'flex justify-center gap-3', dir: 'ltr' }, pad.switches.map((up, i) =>
      h('button', {
        class: 'flex flex-col items-center gap-2', disabled: !live, 'aria-pressed': String(up), 'aria-label': `المفتاح ${i + 1}`,
        onclick: () => { pad.switches[i] = !up; render(true); },
      },
      h('span', { class: `relative h-28 w-12 rounded-full ring-2 ${up ? 'bg-[#2c3a26] ring-sage' : 'bg-black ring-[#57504f]'}` },
        h('span', { class: `absolute inset-x-1 h-12 rounded-full ${up ? 'top-1 bg-sage' : 'bottom-1 bg-cream'}` })),
      h('span', { class: 'font-display font-bold' }, i + 1),
      h('span', { class: `text-xs font-bold ${up ? 'text-sage' : 'text-mutedDk'}` }, up ? 'فوق' : 'تحت')))),
    h('button', { class: 'btn-red text-lg', disabled: !live, onclick: () => submit({ switches: pad.switches.slice() }) }, 'تسليح'),
  ];
}

function defuserScreen() {
  if (pad.round !== S.round) resetPad();
  const d = S.you.defuser || { status: 'waiting', strikes: 0 };
  const racing = (S.phase === 'countdown' || S.phase === 'race') && (d.status === 'racing' || d.status === 'ready');
  const body = { wires: wiresPad, keypad: keypadPad, switches: switchesPad }[S.bomb.type](racing);
  const [label, chip] = DEFUSER_STATUS[d.status];
  const flash = pad.flash && pad.flash.until > Date.now() ? pad.flash : null;
  return [
    h('div', { class: 'flex items-center justify-between gap-2' },
      h('span', { class: `chip px-4 py-1 text-base ${chip}` }, label),
      h('div', { class: 'flex gap-1', 'aria-label': `الضربات ${d.strikes} من ${S.maxStrikes}` }, Array.from({ length: S.maxStrikes }, (_, i) =>
        h('span', { class: `grid h-7 w-7 place-items-center rounded-full text-sm font-bold ${i < d.strikes ? 'bg-red text-clarity' : 'bg-land text-muted'}` }, '✕'))),
      S.phase === 'race' || S.phase === 'hints' ? timer(S.phaseEndsAt) : null),
    S.phase === 'hints' ? h('p', { class: 'panel text-center' }, 'المرشدين يكتبون التلميحات. ادرس القنبلة على التلفزيون، واللوحة تنفتح مع «يلا!».') : null,
    S.phase === 'countdown' ? h('div', { class: 'text-center font-kufi text-8xl leading-[1.4] text-auth', dataset: { go: S.goAt } }) : null,
    S.phase === 'race' && S.hints ? h('p', { class: 'text-center text-sm text-muted' }, 'التلميحين على التلفزيون. واحد مزيّف: لو نفذته تطلع.') : null,
    flash ? h('div', { class: `rounded-xl p-4 text-center font-display text-2xl font-bold animate-shake ${flash.cls}` }, flash.text) : null,
    // locked until GO on the synced clock, even if the 'race' state is still on its way
    h('section', { class: `bomb ${S.phase === 'hints' ? 'locked' : ''}`, dataset: S.phase === 'countdown' ? { arm: S.goAt } : {} },
      h('span', { class: 'font-display font-bold' }, MODULE_NAME[S.bomb.type]), body),
  ];
}

/* ---- round end / game end ---- */

function resultScreen() {
  const r = S.result, you = S.you;
  let headline;
  if (you.role === 'defuser') {
    headline = { defused: 'فكّيتها!', fooled: 'انخدعت بالمزيّف.', out: 'ثلاث ضربات وطلعت.', beaten: 'المفكّك الثاني سبقك.', exploded: 'بووم.' }[you.defuser?.status] || 'خلصت الجولة';
  } else {
    const mine = r.reveal.find(x => x.team === you.team);
    const rival = r.fooled.some(t => t !== you.team), own = r.fooled.includes(you.team);
    headline = mine.truthful ? (r.winner === you.team ? 'مفكّكك صدّقك. نقطة!' : 'قلت الصدق.')
      : rival ? 'مزيّفك مشى عليهم! +1' : own ? 'مزيّفك صاد مفكّك فريقك.' : 'ما أحد صدّق مزيّفك.';
  }
  return [
    h('section', { class: 'night flex flex-col items-center gap-2 px-5 pb-6 text-center' },
      h('div', { class: 'label' }, `الجولة ${r.round}`),
      h('h2', { class: 'font-kufi text-3xl leading-[1.5]' }, headline),
      h('p', { class: 'text-mutedDk' }, r.winner ? `${TEAM[r.winner].name} فكّ القنبلة.` : 'ما أحد فكّ القنبلة.')),
    h('div', { class: 'grid grid-cols-2 gap-3' }, r.reveal.map((x, i) =>
      h('div', { class: `panel gap-1 border-4 p-3 ${x.truthful ? 'border-sage' : 'border-coral'}` },
        h('div', { class: 'text-xs font-bold text-muted' }, `تلميح ${HINT_LABEL[i]} · ${x.truthful ? 'صادق' : 'مزيّف'}`),
        h('p', { class: 'break-words font-bold' }, x.text),
        h('div', {}, teamChip(x.team))))),
    h('div', { class: 'flex items-center justify-center gap-3' },
      h('span', { class: `rounded-xl px-4 font-display text-4xl font-bold ${TEAM.t1.box}` }, S.scores.t1),
      h('span', { class: 'font-display text-2xl text-muted' }, ':'),
      h('span', { class: `rounded-xl px-4 font-display text-4xl font-bold ${TEAM.t2.box}` }, S.scores.t2)),
    h('p', { class: 'text-center text-muted' }, S.round < S.rounds ? 'الجولة الجاية: المرشدين يتبادلون الأدوار.' : 'النتيجة النهائية على التلفزيون.'),
  ];
}

function overScreen() {
  const { t1, t2 } = S.scores, mine = S.you.team;
  const won = t1 === t2 ? null : (t1 > t2 ? 't1' : 't2');
  return [h('section', { class: 'night mt-6 flex flex-col items-center gap-4 px-5 pb-6 text-center' },
    h('div', { class: 'label' }, 'خلصت اللعبة'),
    h('h2', { class: 'font-kufi text-4xl leading-[1.5]' }, won === null ? 'تعادل!' : won === mine ? 'فاز فريقك!' : `فاز ${TEAM[won].name}`),
    h('div', { class: 'flex items-center gap-3' },
      h('span', { class: `rounded-xl px-4 font-display text-5xl font-bold ${TEAM.t1.box}` }, t1),
      h('span', { class: 'font-display text-3xl text-mutedDk' }, ':'),
      h('span', { class: `rounded-xl px-4 font-display text-5xl font-bold ${TEAM.t2.box}` }, t2)),
    h('p', { class: 'text-mutedDk' }, 'المضيف يقدر يبدأ لعبة جديدة من التلفزيون.'))];
}

/* ---------------- render ---------------- */

// A state push (the other guide's hint arriving, say) must not wipe a half-typed hint, so the screen is only rebuilt
// when something this phone shows has actually changed. Local actions pass force.
function screenKey() {
  if (!S) return 'join';
  const y = S.you;
  return JSON.stringify([S.phase, S.round, y.seat, y.role, y.hint, y.defuser?.status, y.defuser?.strikes,
    S.phase === 'lobby' ? [S.seats, S.lobby] : null,
    S.phase === 'hints' && y.hint !== null ? S.hintsIn : null,
    S.phase === 'result' || S.phase === 'over' ? S.scores : null]);
}

function render(force) {
  const key = screenKey();
  if (!force && key === lastKey) return;
  lastKey = key;
  if (!S) return app.replaceChildren(...joinScreen().filter(Boolean));
  const you = S.you;
  let body;
  if (S.phase === 'lobby') body = lobbyScreen();
  else if (S.phase === 'over') body = overScreen();
  else if (S.phase === 'result') body = resultScreen();
  else if (you.role === 'defuser') body = defuserScreen();
  else if (you.role) body = guideScreen();
  else body = [h('p', { class: 'panel text-center' }, 'اللعبة شغّالة، وأنت تتفرّج.')];
  app.replaceChildren(topBar(), ...body.filter(Boolean)); // replaceChildren would print a null as the text "null"
}

render(true);

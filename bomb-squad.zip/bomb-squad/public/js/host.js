'use strict';
/* The TV: room code and seats in the lobby; in the game, team 1 | the bomb on the rug and the hints | team 2. */
const socket = io();
const app = document.getElementById('app');
let S = null;

Clock.start(socket);
startTickers();

// A refresh or a dropped connection resumes the same room; only a first visit creates one.
socket.on('connect', async () => {
  let saved = null;
  try { saved = JSON.parse(sessionStorage.getItem('bs.host') || 'null'); } catch {}
  let res = saved ? await emit(socket, 'host:resume', saved) : null;
  if (!res || !res.ok) res = await emit(socket, 'host:create');
  if (res.ok) sessionStorage.setItem('bs.host', JSON.stringify({ code: res.code, hostToken: res.hostToken }));
  else toast(res.error);
});
socket.on('state', s => { S = s; render(); });
socket.on('kicked', msg => { sessionStorage.removeItem('bs.host'); app.replaceChildren(h('p', { class: 'panel m-10 text-2xl' }, msg)); });

const act = async (event, data) => { const r = await emit(socket, event, data); if (!r.ok) toast(r.error); };
const joinUrl = () => `${location.origin}/play`;
const teamChip = (t, cls = '') => h('span', { class: `chip ${TEAM[t].box} ${cls}` }, TEAM[t].name);
const scoreChip = (t, cls = 'text-6xl') => h('span', { class: `rounded-2xl px-6 font-display font-bold tabular-nums ${TEAM[t].box} ${cls}` }, S.scores[t]);

function seatCard(seat) {
  const p = S.seats[seat];
  return h('div', { class: 'flex items-center justify-between gap-4 rounded-xl bg-surface px-5 py-4 text-resolve' },
    h('div', {},
      h('div', { class: 'label' }, SEAT_LABEL[seat]),
      h('div', { class: `font-display text-3xl font-bold ${p ? 'text-auth' : 'text-land'}` }, p ? p.name : 'فاضي'),
      p && !p.connected ? h('div', { class: 'text-sm font-bold text-red' }, 'انقطع') : null),
    p ? h('button', { class: 'btn-ghost min-h-0 px-3 py-2 text-sm', title: 'فضّ الكرسي', onclick: () => act('host:kick', { seat }) }, '✕') : null);
}

function lobby() {
  const full = Object.values(S.seats).every(p => p && p.connected);
  const seated = Object.values(S.seats).filter(Boolean).length;
  const teamCol = t => h('section', { class: `flex flex-col gap-4 rounded-2xl p-6 ${TEAM[t].box}` },
    h('h2', { class: 'font-display text-3xl font-bold text-current' }, TEAM[t].name),
    seatCard(`${t}d`), seatCard(`${t}g`));
  return h('main', { class: 'mx-auto flex min-h-screen max-w-[1500px] flex-col gap-10 px-10 pb-10 pt-14' },
    h('header', { class: 'flex flex-col items-center gap-3 text-center' },
      h('h1', { class: 'font-kufi text-[96px] leading-[1.3]' }, 'المخرّب'),
      h('div', { class: 'sadu w-[360px]', 'aria-hidden': 'true' }),
      h('p', { class: 'max-w-[44ch] text-xl text-muted' }, 'فكّ القنبلة على أربعة: مفكّكين يتسابقون، ومرشدين واحد منهم يكذب.')),
    h('div', { class: 'grid flex-1 grid-cols-[1fr_auto_1fr] items-start gap-10' },
      teamCol('t1'),
      h('section', { class: 'panel items-center gap-4 px-12 py-10 text-center' },
        h('div', { class: 'label text-base' }, 'ادخلوا من جوالاتكم'),
        h('div', { class: 'font-mono text-2xl text-auth', dir: 'ltr' }, joinUrl()),
        h('div', { class: 'label mt-2 text-base' }, 'رمز الغرفة'),
        h('div', { class: 'rounded-2xl bg-resolve px-8 py-2 font-display text-8xl font-bold tracking-[.2em] text-clarity', dir: 'ltr' }, S.code),
        S.lobby.length ? h('p', { class: 'text-muted' }, `بالانتظار بدون كرسي: ${S.lobby.join('، ')}`) : null,
        h('button', { class: 'btn mt-2 w-full text-2xl', disabled: !full, onclick: () => act('host:start') },
          full ? 'ابدأ اللعبة' : `ننتظر اللاعبين (${seated} من 4)`)),
      teamCol('t2')));
}

function teamPanel(t) {
  const d = S.defusers?.[t], [label, chip] = DEFUSER_STATUS[d?.status || 'waiting'];
  const defuser = S.seats[`${t}d`], guide = S.seats[`${t}g`];
  const hit = d?.status === 'fooled' || d?.status === 'out';
  return h('section', { class: `flex flex-col gap-4 rounded-2xl p-5 ${TEAM[t].box} ${hit ? 'animate-shake' : ''}` },
    h('div', { class: 'flex items-center justify-between' },
      h('h2', { class: 'font-display text-3xl font-bold text-current' }, TEAM[t].name),
      h('span', { class: 'font-display text-6xl font-bold tabular-nums' }, S.scores[t])),
    h('div', { class: 'flex flex-col gap-2 rounded-xl bg-surface p-4 text-resolve' },
      h('div', { class: 'label' }, 'المفكّك'),
      h('div', { class: 'font-display text-3xl font-bold text-auth' }, defuser?.name || '—',
        defuser && !defuser.connected ? h('span', { class: 'ms-2 text-base text-red' }, 'انقطع') : null),
      h('span', { class: `chip self-start px-4 py-1 text-xl ${chip}` }, label),
      h('div', { class: 'flex gap-2', 'aria-label': `الضربات ${d?.strikes || 0} من ${S.maxStrikes}` }, Array.from({ length: S.maxStrikes }, (_, i) =>
        h('span', { class: `grid h-9 w-9 place-items-center rounded-full font-bold ${i < (d?.strikes || 0) ? 'bg-red text-clarity' : 'bg-land text-muted'}` }, '✕')))),
    h('div', { class: 'flex flex-col gap-1 rounded-xl bg-surface p-4 text-resolve' },
      h('div', { class: 'label' }, 'المرشد'),
      h('div', { class: 'font-display text-2xl font-bold text-auth' }, guide?.name || '—',
        guide && !guide.connected ? h('span', { class: 'ms-2 text-base text-red' }, 'انقطع') : null),
      // the TV never says which guide holds the truth
      h('div', { class: 'text-muted' }, 'صادق ولا مخرّب؟')));
}

function hintsPanel() {
  if (!S.hints) {
    return h('div', { class: 'panel items-center gap-2 py-8 text-center' },
      h('div', { class: 'label text-base' }, 'الإرسال الواصل'),
      h('div', { class: 'font-display text-5xl font-bold text-auth' }, `${S.hintsIn} من 2`),
      h('p', { class: 'text-lg text-muted' }, 'المرشدين يكتبون. يا المفكّكين: ادرسوا القنبلة.'));
  }
  // A and B are built from identical markup: the only difference on screen is the words
  return h('div', { class: 'grid grid-cols-2 gap-5' }, S.hints.map((hint, i) =>
    h('div', { class: 'night flex min-h-[10rem] flex-col gap-3 px-6 pb-6' },
      h('div', { class: 'font-display text-2xl font-bold text-gold' }, `[تلميح ${HINT_LABEL[i]}]`),
      h('p', { class: 'break-words text-3xl font-bold leading-snug' }, hint.text))));
}

const overlay = (...kids) => h('div', { class: 'fixed inset-0 z-40 grid place-items-center overflow-auto bg-clarity/95 p-10 pt-14' }, ...kids);

function resultOverlay() {
  const r = S.result, last = S.round >= S.rounds;
  const headline = r.winner ? `${TEAM[r.winner].name} فكّها!` : r.reason === 'time' ? 'بووم! خلص الوقت.' : 'بووم! المفكّكين الاثنين طلعوا.';
  return overlay(h('div', { class: 'night flex w-full max-w-5xl flex-col items-center gap-6 px-10 pb-10 text-center' },
    h('div', { class: 'label text-base' }, `الجولة ${r.round} · ${r.location}`),
    h('h2', { class: `font-kufi text-7xl leading-[1.3] animate-pop ${r.winner ? '' : '!text-coral'}` }, headline),
    h('div', { class: 'grid w-full grid-cols-2 gap-5 text-start' }, r.reveal.map((x, i) =>
      h('div', { class: `flex flex-col gap-3 rounded-2xl border-4 bg-clarity p-5 text-resolve ${x.truthful ? 'border-sage' : 'border-coral'}` },
        h('div', { class: 'flex items-center justify-between gap-2' },
          h('span', { class: 'font-display text-xl font-bold text-auth' }, `[تلميح ${HINT_LABEL[i]}]`),
          h('span', { class: `chip px-4 py-1 text-base ${x.truthful ? 'bg-sage text-resolve' : 'bg-red text-clarity'}` }, x.truthful ? 'المرشد الصادق' : 'المخرّب')),
        h('p', { class: 'break-words text-2xl font-bold' }, x.text),
        h('div', { class: 'flex items-center gap-2' }, teamChip(x.team), h('span', { class: 'font-bold' }, S.seats[`${x.team}g`]?.name || ''))))),
    h('div', { class: 'grid w-full grid-cols-2 gap-5 text-start text-xl' },
      h('div', { class: 'rounded-xl bg-gold p-4 text-resolve' }, h('div', { class: 'text-sm text-auth' }, 'الحل الصح'), h('b', {}, r.solutionText)),
      h('div', { class: 'rounded-xl bg-coral p-4 text-resolve' }, h('div', { class: 'text-sm' }, 'الحل المزيّف'), h('b', {}, r.decoyText))),
    r.fooled.length ? h('p', { class: 'text-xl text-coral' }, r.fooled.map(t =>
      `مفكّك ${TEAM[t].name} انخدع بالمزيّف${t !== r.saboteurTeam ? ` (+1 لـ${TEAM[r.saboteurTeam].name})` : ''}.`).join(' ')) : null,
    h('div', { class: 'flex items-center gap-6' }, scoreChip('t1'), h('span', { class: 'font-display text-4xl text-mutedDk' }, ':'), scoreChip('t2')),
    h('div', { class: 'flex items-center gap-4' },
      h('button', { class: 'btn-gold text-2xl', onclick: () => act('host:next') }, last ? 'النتيجة النهائية' : 'الجولة الجاية: المرشدين يتبادلون'),
      h('span', { class: 'text-mutedDk' }, 'تلقائيًا بعد ', h('span', { dir: 'ltr', dataset: { until: S.phaseEndsAt } })))));
}

function overScreen() {
  const { t1, t2 } = S.scores, winner = t1 === t2 ? null : t1 > t2 ? 't1' : 't2';
  return overlay(h('div', { class: 'night flex w-full max-w-4xl flex-col items-center gap-8 px-10 pb-10 text-center' },
    h('div', { class: 'label text-base' }, 'خلصت اللعبة'),
    h('h2', { class: 'font-kufi text-8xl leading-[1.3] animate-pop' }, winner ? `فاز ${TEAM[winner].name}!` : 'تعادل!'),
    h('div', { class: 'flex items-center gap-6' }, scoreChip('t1', 'text-7xl'), h('span', { class: 'font-display text-5xl text-mutedDk' }, ':'), scoreChip('t2', 'text-7xl')),
    h('ol', { class: 'flex w-full flex-col gap-2 text-xl' }, S.history.map(r =>
      h('li', { class: 'flex items-center justify-between gap-4 rounded-xl bg-clarity px-5 py-3 text-resolve' },
        h('span', {}, `الجولة ${r.round} · ${r.location}`),
        r.winner ? teamChip(r.winner, 'text-base') : h('span', { class: 'chip bg-resolve text-base text-coral' }, 'بووم')))),
    h('button', { class: 'btn-gold text-2xl', onclick: () => act('host:start') }, 'لعبة جديدة بنفس الكراسي')));
}

function game() {
  const timerTs = S.phase === 'hints' || S.phase === 'race' ? S.phaseEndsAt : null;
  const phaseLabel = { hints: 'المرشدين يكتبون التلميحات', countdown: 'استعدوا…', race: 'فكّوها!', result: 'خلصت الجولة', over: 'خلصت اللعبة' }[S.phase];
  return h('main', { class: 'flex h-screen flex-col gap-6 px-8 pb-8 pt-12' },
    h('header', { class: 'flex items-end justify-between gap-6' },
      h('div', {},
        h('div', { class: 'label text-base' }, `الجولة ${S.round} من ${S.rounds} · الرمز `, h('b', { dir: 'ltr', class: 'tracking-widest text-resolve' }, S.code)),
        h('h1', { class: 'font-display text-4xl' }, S.bomb.location)),
      h('div', { class: 'text-end' },
        h('div', { class: 'font-display text-xl font-bold text-auth' }, phaseLabel),
        h('div', { class: 'font-display text-6xl font-bold tabular-nums text-resolve', dir: 'ltr', dataset: timerTs ? { until: timerTs } : {} }, timerTs ? '' : '--:--'))),
    h('div', { class: 'grid min-h-0 flex-1 grid-cols-[minmax(0,1fr)_minmax(0,2fr)_minmax(0,1fr)] gap-8' },
      teamPanel('t1'),
      h('section', { class: 'flex min-h-0 flex-col gap-6' },
        h('div', { class: 'felt px-10 py-12' }, bombArt(S.bomb, { untilTs: timerTs, big: true })),
        hintsPanel()),
      teamPanel('t2')),
    S.phase === 'countdown' ? h('div', { class: 'fixed inset-0 z-40 grid place-items-center bg-resolve/90' },
      h('div', { class: 'text-center' },
        h('div', { class: 'mb-4 font-display text-3xl text-mutedDk' }, 'يا المفكّكين، الجوالات بيدكم'),
        h('div', { class: 'font-kufi text-[14rem] leading-[1.3] text-gold', dataset: { go: S.goAt } }))) : null,
    S.phase === 'result' ? resultOverlay() : null,
    S.phase === 'over' ? overScreen() : null);
}

function render() {
  if (!S) return;
  app.replaceChildren(S.phase === 'lobby' ? lobby() : game());
}

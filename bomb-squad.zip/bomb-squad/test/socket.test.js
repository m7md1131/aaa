'use strict';
// End to end over real sockets: one TV and four phones play a full two-round game against a live server.
Object.assign(process.env, { HINT_MS: '5000', COUNTDOWN_MS: '150', RACE_MS: '5000', RESULT_MS: '5000', FIRST_TRUE_TEAM: 't1' });

const test = require('node:test');
const assert = require('node:assert/strict');
const { io: connect } = require('socket.io-client');
const { createServer } = require('../server');

const sleep = ms => new Promise(r => setTimeout(r, ms));
const call = (sock, event, data = {}) => new Promise(res => sock.emit(event, data, res));

function client(url) {
  const sock = connect(url, { transports: ['websocket'], forceNew: true });
  sock.states = [];
  sock.on('state', s => { sock.last = s; sock.states.push(s); });
  return new Promise(res => sock.on('connect', () => res(sock)));
}
const waitFor = async (pred, ms = 3000) => {
  const end = Date.now() + ms;
  while (Date.now() < end) { if (pred()) return; await sleep(10); }
  throw new Error('timed out waiting');
};
function payloadFor(bomb, key) {
  if (bomb.type === 'wires') return { cuts: key.split(',').map(Number) };
  if (bomb.type === 'keypad') return { code: key };
  return { switches: [...key].map(c => c === '1') };
}

test('a full game over Socket.io, with per-recipient secrecy', async () => {
  const { server, io, manager } = createServer();
  await new Promise(r => server.listen(0, r));
  const url = `http://localhost:${server.address().port}`;
  const socks = [];
  try {
    const tv = await client(url);
    socks.push(tv);
    const created = await call(tv, 'host:create');
    assert.ok(created.ok && /^[A-Z]{4}$/.test(created.code));

    // clock sync answers with the server time
    const ping = await new Promise(r => tv.emit('clock:ping', Date.now(), r));
    assert.ok(Math.abs(ping.server - Date.now()) < 1000);

    const phones = {};
    for (const seat of ['t1d', 't1g', 't2d', 't2g']) {
      const s = await client(url);
      socks.push(s);
      const j = await call(s, 'player:join', { code: created.code.toLowerCase(), name: `P-${seat}` });
      assert.ok(j.ok, j.error);
      s.playerId = j.playerId;
      assert.ok((await call(s, 'player:seat', { seat })).ok);
      phones[seat] = s;
    }
    assert.equal((await call(phones.t1d, 'host:start')).ok, false, 'a phone cannot act as host');
    assert.ok((await call(tv, 'host:start')).ok);
    await waitFor(() => tv.last.phase === 'hints');
    const room = manager.get(created.code);

    for (let round = 1; round <= 2; round++) {
      await waitFor(() => tv.last.phase === 'hints' && tv.last.round === round);
      const trueSeat = round === 1 ? 't1g' : 't2g', sabSeat = round === 1 ? 't2g' : 't1g';
      await waitFor(() => phones[trueSeat].last.you.brief && phones[sabSeat].last.you.keywords);
      assert.ok(!phones[sabSeat].last.you.brief, 'the saboteur must never get the brief');

      const r1 = await call(phones[trueSeat], 'guide:hint', { text: 'TRUE\u202E hint   ' + 'x'.repeat(80) });
      assert.equal(Array.from(r1.hint).length, 50);
      await call(phones[sabSeat], 'guide:hint', { text: 'fake hint' });
      await waitFor(() => tv.last.phase === 'countdown');
      // every phone and the TV count down to the same server timestamp
      const goAt = tv.last.goAt;
      await waitFor(() => Object.values(phones).every(p => p.last.goAt === goAt));

      const early = await call(phones.t1d, 'defuser:submit', payloadFor(room.bomb, room.bomb.solution));
      assert.equal(early.ok, false);
      await sleep(goAt - Date.now() + 5);

      // round 1: Team 1 defuses. round 2: Team 2's defuser defuses
      const winner = round === 1 ? 't1d' : 't2d';
      const res = await call(phones[winner], 'defuser:submit', payloadFor(room.bomb, room.bomb.solution));
      assert.equal(res.outcome, 'defused');
      await waitFor(() => tv.last.phase === 'result');
      assert.equal(tv.last.result.winner, winner.slice(0, 2));
      if (round === 1) assert.ok((await call(tv, 'host:next')).ok);
    }
    assert.deepEqual(tv.last.scores, { t1: 1, t2: 1 });
    assert.ok((await call(tv, 'host:next')).ok);
    await waitFor(() => tv.last.phase === 'over');

    // nothing secret ever reached the TV or a defuser while a round was live
    // (history holds earlier rounds' answers on purpose: those were revealed when their round ended)
    for (const s of [tv, phones.t1d, phones.t2d]) {
      for (const st of s.states.filter(x => ['hints', 'countdown', 'race'].includes(x.phase))) {
        const secret = room.history[st.round - 1].solutionText;
        const json = JSON.stringify({ ...st, history: [] });
        assert.ok(!json.includes(secret), `round ${st.round} solution leaked`);
        assert.ok(!json.includes('"keywords"') && !json.includes('"steps"') && !json.includes('"story"'), 'a brief leaked');
      }
    }

    // a reloaded phone rejoins its seat with its stored id
    phones.t1g.disconnect();
    await waitFor(() => tv.last.seats.t1g && tv.last.seats.t1g.connected === false);
    const back = await client(url);
    socks.push(back);
    const rejoin = await call(back, 'player:join', { code: created.code, playerId: phones.t1g.playerId });
    assert.ok(rejoin.ok);
    await waitFor(() => back.last && back.last.you.seat === 't1g' && tv.last.seats.t1g.connected);
  } finally {
    socks.forEach(s => s.close());
    for (const r of manager.rooms.values()) r.dispose();
    io.close();
    server.close();
  }
});

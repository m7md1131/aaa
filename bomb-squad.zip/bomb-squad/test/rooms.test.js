'use strict';
// Short timings so whole rounds run in milliseconds; config reads these once at require time.
Object.assign(process.env, { HINT_MS: '200', COUNTDOWN_MS: '40', RACE_MS: '1500', RESULT_MS: '5000', FIRST_TRUE_TEAM: 't1' });

const test = require('node:test');
const assert = require('node:assert/strict');
const { Room, NO_HINT } = require('../server/rooms');
const { generateBomb, normalizeSubmission } = require('../server/bombs');
const { cleanHint } = require('../server/sanitize');

const sleep = ms => new Promise(r => setTimeout(r, ms));

// The payload a phone would send to produce a given key.
function payloadFor(bomb, key) {
  if (bomb.type === 'wires') return { cuts: key.split(',').map(Number) };
  if (bomb.type === 'keypad') return { code: key };
  return { switches: [...key].map(c => c === '1') };
}
// Any valid input that is neither the solution nor the decoy: a plain strike.
function wrongKey(bomb) {
  const candidates = bomb.type === 'wires' ? ['0,1', '1,0', '2,3', '3,2']
    : bomb.type === 'keypad' ? ['0000', '1111', '2222']
    : ['00000', '11111', '10101'];
  return candidates.find(k => k !== bomb.solution && k !== bomb.decoy);
}

function fullRoom() {
  const room = new Room('TEST');
  const ids = {};
  for (const seat of ['t1d', 't1g', 't2d', 't2g']) {
    const p = room.join(seat.toUpperCase(), null, `sock-${seat}`);
    room.takeSeat(p.id, seat);
    ids[seat] = p.id;
  }
  return { room, ids };
}

test('hints are sanitized: invisible and bidi characters go, whitespace collapses, 50 code points max', () => {
  assert.equal(cleanHint('  cut\u202E the\u200B   red\n\nwire  '), 'cut the red wire');
  assert.equal(Array.from(cleanHint('💣'.repeat(80))).length, 50);
  assert.equal(cleanHint('<b>x</b>'), '<b>x</b>'); // kept as text; the clients render it as text, never HTML
  assert.equal(cleanHint('\u0000\u0007'), '');
});

test('every generated bomb has a distinct decoy, and both keys round-trip through the input normalizer', () => {
  for (let i = 0; i < 500; i++) {
    const b = generateBomb();
    assert.notEqual(b.solution, b.decoy);
    assert.equal(normalizeSubmission(b, payloadFor(b, b.solution)), b.solution);
    assert.equal(normalizeSubmission(b, payloadFor(b, b.decoy)), b.decoy);
    assert.ok(b.keywords.length >= 3 && b.keywords.length <= 5);
  }
  const wires = (() => { let b; do { b = generateBomb(); } while (b.type !== 'wires'); return b; })();
  assert.equal(normalizeSubmission(wires, { cuts: [1, 1] }), null);
  assert.equal(normalizeSubmission(wires, { cuts: [0, 99] }), null);
  assert.equal(normalizeSubmission(wires, 'junk'), null);
});

test('only the true guide gets the brief; the saboteur gets keywords; defusers and the TV get neither', () => {
  const { room, ids } = fullRoom();
  room.start();
  assert.equal(room.phase, 'hints');
  const g1 = room.stateFor(ids.t1g).you, g2 = room.stateFor(ids.t2g).you;
  assert.equal(g1.role, 'guide');
  assert.ok(g1.brief.steps.length && !g1.keywords);
  assert.equal(g2.role, 'saboteur');
  assert.ok(g2.keywords.length && !g2.brief);
  for (const view of [room.hostState(), room.stateFor(ids.t1d), room.stateFor(ids.t2d)]) {
    const json = JSON.stringify(view);
    assert.ok(!json.includes(room.bomb.solutionText) && !json.includes(room.bomb.steps[0]) && !json.includes('keywords'), 'secret leaked');
    assert.ok(!json.includes(room.bomb.story));
  }
  room.dispose();
});

test('a full game: anonymous hints, synced start, fake hint, strikes, scoring and the role swap', async () => {
  const { room, ids } = fullRoom();
  room.start();

  // round 1: Team 1's guide holds the truth
  room.submitHint(ids.t1g, 'the real one');
  assert.equal(room.phase, 'hints');
  assert.equal(room.hostState().hints, null, 'hints stay hidden until both are in');
  assert.throws(() => room.submitHint(ids.t1g, 'again'), /خلاص/);
  assert.throws(() => room.submitHint(ids.t1d, 'x'), /للمرشدين/);
  room.submitHint(ids.t2g, 'the fake one');
  assert.equal(room.phase, 'countdown');
  const shown = room.hostState().hints;
  assert.deepEqual(shown.map(x => Object.keys(x).sort()), [['label', 'text'], ['label', 'text']]);
  assert.deepEqual(shown.map(x => x.text).sort(), ['the fake one', 'the real one']);

  const b = room.bomb;
  assert.throws(() => room.submitDefuse(ids.t1d, payloadFor(b, b.solution)), /مو الحين/);
  await sleep(60);

  // Team 2's defuser runs the fake. Team 2 is the saboteur's own team: out, but no point for anyone.
  assert.equal(room.submitDefuse(ids.t2d, payloadFor(b, b.decoy)).outcome, 'fooled');
  assert.deepEqual(room.scores, { t1: 0, t2: 0 });
  assert.throws(() => room.submitDefuse(ids.t2d, payloadFor(b, b.solution)), /طلعت/);

  // Team 1's defuser strikes once, then defuses
  assert.equal(room.submitDefuse(ids.t1d, payloadFor(b, wrongKey(b))).outcome, 'strike');
  assert.throws(() => room.submitDefuse(ids.t1d, payloadFor(b, b.solution)), /على هونك/);
  await sleep(260);
  assert.equal(room.submitDefuse(ids.t1d, payloadFor(b, b.solution)).outcome, 'defused');
  assert.equal(room.phase, 'result');
  assert.deepEqual(room.scores, { t1: 1, t2: 0 });
  const truthful = room.result.reveal.find(x => x.truthful);
  assert.equal(truthful.team, 't1');
  assert.equal(truthful.text, 'the real one');

  // round 2: the guides swap roles and a new bomb is loaded
  const firstBomb = room.bomb;
  room.next();
  assert.equal(room.round, 2);
  assert.equal(room.phase, 'hints');
  assert.notEqual(room.bomb.locationId, firstBomb.locationId);
  assert.equal(room.stateFor(ids.t1g).you.role, 'saboteur');
  assert.ok(room.stateFor(ids.t1g).you.keywords);
  assert.equal(room.stateFor(ids.t2g).you.role, 'guide');
  assert.ok(room.stateFor(ids.t2g).you.brief);

  room.submitHint(ids.t1g, 'lies');
  room.submitHint(ids.t2g, 'truth');
  await sleep(60);
  const b2 = room.bomb;
  // Team 2's defuser falls for Team 1's fake: Team 1 scores the sabotage
  assert.equal(room.submitDefuse(ids.t2d, payloadFor(b2, b2.decoy)).outcome, 'fooled');
  assert.deepEqual(room.scores, { t1: 2, t2: 0 });
  // Team 1's defuser burns three strikes: nobody left racing, the round ends with no winner
  for (let i = 0; i < 3; i++) {
    const out = room.submitDefuse(ids.t1d, payloadFor(b2, wrongKey(b2))).outcome;
    assert.equal(out, i < 2 ? 'strike' : 'out');
    await sleep(260);
  }
  assert.equal(room.phase, 'result');
  assert.equal(room.result.winner, null);
  assert.equal(room.result.reason, 'all-out');

  room.next();
  assert.equal(room.phase, 'over');
  assert.equal(room.history.length, 2);

  // play again keeps the seats and resets the score
  room.start();
  assert.equal(room.phase, 'hints');
  assert.deepEqual(room.scores, { t1: 0, t2: 0 });
  room.dispose();
});

test('timers: a missing hint becomes NO_HINT, and the race ends on time', async () => {
  const { room, ids } = fullRoom();
  room.start();
  room.submitHint(ids.t1g, 'only one');
  await sleep(320); // HINT_MS + margin; by now the 40 ms countdown may be over too
  assert.ok(['countdown', 'race'].includes(room.phase));
  assert.ok(room.hostState().hints.some(x => x.text === NO_HINT));
  await sleep(1750); // COUNTDOWN_MS + RACE_MS + margin
  assert.equal(room.phase, 'result');
  assert.equal(room.result.reason, 'time');
  assert.equal(room.defusers.t1.status, 'exploded');
  room.dispose();
});

test('lobby rules: unique names, locked seats, four connected players to start', () => {
  const room = new Room('LOBY');
  const a = room.join('Sam', null, 's1');
  assert.throws(() => room.join('sam', null, 's2'), /مأخوذ/);
  assert.throws(() => room.join('   ', null, 's2'), /اسمك/);
  room.takeSeat(a.id, 't1d');
  const b = room.join('Ana', null, 's2');
  assert.throws(() => room.takeSeat(b.id, 't1d'), /مأخوذ/);
  assert.throws(() => room.start(), /الأربعة/);
  // a reload rejoins with the same id and keeps the seat
  assert.equal(room.join('ignored', a.id, 's9').id, a.id);
  assert.equal(room.seatOf(a.id), 't1d');
  room.dispose();
});

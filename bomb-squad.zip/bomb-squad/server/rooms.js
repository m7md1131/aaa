'use strict';
const { randomBytes, randomInt } = require('crypto');
const cfg = require('./config');
const { generateBomb, normalizeSubmission } = require('./bombs');
const { cleanHint, cleanName } = require('./sanitize');

/*
 * The authoritative game. Socket-free on purpose: the room calls onChange(room) after every mutation, and the
 * transport layer (index.js) decides who receives which view. Every view is built per recipient, so the true
 * brief, the saboteur's keywords and the solution never leave the server toward anyone who may not see them.
 *
 *   lobby ──start──▶ hints ──both sent / time──▶ countdown ──goAt──▶ race ──defused / both out / time──▶ result
 *                     ▲                                                                                  │
 *                     └──────────── next round: the guides swap roles, a new bomb is loaded ◀───────────┤
 *                                                                                                        ▼
 *                                                               over ◀── last round ──────────────────────┘
 */

const SEATS = ['t1d', 't1g', 't2d', 't2g'];
const SEAT_INFO = {
  t1d: { team: 't1', kind: 'defuser' },
  t1g: { team: 't1', kind: 'guide' },
  t2d: { team: 't2', kind: 'defuser' },
  t2g: { team: 't2', kind: 'guide' },
};
const TEAMS = ['t1', 't2'];
const otherTeam = t => (t === 't1' ? 't2' : 't1');
const NO_HINT = '(انقطع الإرسال)';
const CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ'; // no I or O: they read as 1 and 0 across a room

class GameError extends Error {}

class Room {
  constructor(code, onChange = () => {}) {
    this.code = code;
    this.hostToken = randomBytes(16).toString('hex');
    this.hostSocket = null;
    this.onChange = onChange;
    this.players = new Map(); // id -> { id, name, socketId }
    this.seats = Object.fromEntries(SEATS.map(s => [s, null]));
    this.timer = null;
    this.lastActive = Date.now();
    this.resetGame();
  }

  resetGame() {
    clearTimeout(this.timer);
    this.timer = null;
    this.phase = 'lobby';
    this.round = 0;
    this.rounds = cfg.ROUNDS;
    this.scores = { t1: 0, t2: 0 };
    this.trueTeam = null;
    this.bomb = null;
    this.hints = { t1: null, t2: null };
    this.hintOrder = null;
    this.defusers = null;
    this.phaseEndsAt = null;
    this.goAt = null;
    this.result = null;
    this.history = [];
  }

  changed() {
    this.lastActive = Date.now();
    this.onChange(this);
  }

  // Runs fn after ms, unless the phase moves on first; a stale timer must never act on a newer phase.
  after(ms, fn) {
    clearTimeout(this.timer);
    const phase = this.phase, round = this.round;
    this.timer = setTimeout(() => {
      this.timer = null;
      if (this.phase !== phase || this.round !== round) return;
      fn();
      this.changed();
    }, ms);
  }

  dispose() {
    clearTimeout(this.timer);
    this.timer = null;
  }

  /* ---------------- lobby ---------------- */

  join(rawName, playerId, socketId) {
    const known = playerId && this.players.get(playerId);
    if (known) { // a reload or a dropped connection: same player, new socket
      known.socketId = socketId;
      return known;
    }
    if (this.phase !== 'lobby') throw new GameError('اللعبة بدأت خلاص.');
    if (this.players.size >= cfg.MAX_PLAYERS) throw new GameError('الغرفة مليانة.');
    const name = cleanName(rawName);
    if (!name) throw new GameError('اكتب اسمك أول.');
    if ([...this.players.values()].some(p => p.name.toLowerCase() === name.toLowerCase())) throw new GameError('هالاسم مأخوذ بهالغرفة.');
    const player = { id: randomBytes(12).toString('hex'), name, socketId };
    this.players.set(player.id, player);
    return player;
  }

  seatOf(playerId) {
    return SEATS.find(s => this.seats[s] === playerId) || null;
  }

  takeSeat(playerId, seat) {
    if (this.phase !== 'lobby') throw new GameError('الكراسي تتقفل أول ما تبدأ اللعبة.');
    if (!SEATS.includes(seat)) throw new GameError('كرسي غير معروف.');
    if (this.seats[seat] && this.seats[seat] !== playerId) throw new GameError('هالكرسي مأخوذ.');
    const current = this.seatOf(playerId);
    if (current) this.seats[current] = null;
    this.seats[seat] = playerId;
  }

  leaveSeat(playerId) {
    if (this.phase !== 'lobby') throw new GameError('الكراسي تتقفل أول ما تبدأ اللعبة.');
    const current = this.seatOf(playerId);
    if (current) this.seats[current] = null;
  }

  kick(seat) {
    if (this.phase !== 'lobby') throw new GameError('تقدر تفضّي الكراسي بالانتظار بس.');
    const id = this.seats[seat];
    if (!id) return;
    this.seats[seat] = null;
    this.players.delete(id);
    return id;
  }

  disconnect(socketId) {
    for (const p of this.players.values()) {
      if (p.socketId !== socketId) continue;
      p.socketId = null;
      // An unseated phone that leaves the lobby is simply gone; a seated player keeps the seat to come back to.
      if (this.phase === 'lobby' && !this.seatOf(p.id)) this.players.delete(p.id);
    }
  }

  /* ---------------- the game ---------------- */

  start() {
    if (this.phase !== 'lobby' && this.phase !== 'over') throw new GameError('اللعبة شغّالة.');
    const missing = SEATS.filter(s => !this.seats[s] || !this.players.get(this.seats[s])?.socketId);
    if (missing.length) throw new GameError('لازم الكراسي الأربعة كلها فيها لاعبين متصلين.');
    const seats = { ...this.seats };
    this.resetGame();
    this.seats = seats;
    this.round = 1;
    this.trueTeam = cfg.FIRST_TRUE_TEAM === 'random' ? (randomInt(2) ? 't1' : 't2') : cfg.FIRST_TRUE_TEAM;
    this.startRound();
  }

  startRound() {
    const prev = this.bomb;
    this.bomb = generateBomb(prev ? { location: prev.locationId, type: prev.type } : {});
    this.hints = { t1: null, t2: null };
    this.hintOrder = null;
    this.result = null;
    this.goAt = null;
    this.defusers = Object.fromEntries(TEAMS.map(t => [t, { status: 'waiting', strikes: 0, lastAt: 0, feedback: null }]));
    this.phase = 'hints';
    this.phaseEndsAt = Date.now() + cfg.HINT_MS;
    this.after(cfg.HINT_MS, () => this.endHints());
  }

  submitHint(playerId, text) {
    const seat = this.seatOf(playerId);
    if (!seat || SEAT_INFO[seat].kind !== 'guide') throw new GameError('التلميحات للمرشدين بس.');
    if (this.phase !== 'hints') throw new GameError('وقت التلميحات خلص.');
    const team = SEAT_INFO[seat].team;
    if (this.hints[team] !== null) throw new GameError('أرسلت تلميحك خلاص.');
    const hint = cleanHint(text);
    if (!hint) throw new GameError('اكتب شي أول.');
    this.hints[team] = hint;
    if (TEAMS.every(t => this.hints[t] !== null)) this.endHints();
    return hint;
  }

  endHints() {
    for (const t of TEAMS) if (this.hints[t] === null) this.hints[t] = NO_HINT;
    // A coin flip, not submission order, decides which hint is A: who typed faster must reveal nothing.
    this.hintOrder = randomInt(2) ? ['t1', 't2'] : ['t2', 't1'];
    for (const t of TEAMS) this.defusers[t].status = 'ready';
    this.phase = 'countdown';
    this.goAt = Date.now() + cfg.COUNTDOWN_MS;
    this.phaseEndsAt = this.goAt;
    this.after(cfg.COUNTDOWN_MS, () => this.startRace());
  }

  startRace() {
    if (this.phase !== 'countdown') return;
    for (const t of TEAMS) this.defusers[t].status = 'racing';
    this.phase = 'race';
    this.phaseEndsAt = this.goAt + cfg.RACE_MS;
    this.after(Math.max(0, this.phaseEndsAt - Date.now()), () => this.endRound(null, 'time'));
  }

  // The server's receive time is the race's only clock: whoever's correct input arrives first wins.
  submitDefuse(playerId, payload) {
    const seat = this.seatOf(playerId);
    if (!seat || SEAT_INFO[seat].kind !== 'defuser') throw new GameError('القنبلة للمفككين بس.');
    const now = Date.now();
    if (this.phase === 'countdown' && now >= this.goAt) this.startRace(); // the GO timer may lag the clock by a few ms
    if (this.phase !== 'race') throw new GameError(this.phase === 'countdown' ? 'مو الحين!' : 'الجولة خلصت.');
    const team = SEAT_INFO[seat].team;
    const me = this.defusers[team];
    if (me.status !== 'racing') throw new GameError('طلعت من هالجولة.');
    if (now - me.lastAt < cfg.SUBMIT_COOLDOWN_MS) throw new GameError('على هونك.');
    me.lastAt = now;

    const key = normalizeSubmission(this.bomb, payload);
    if (key === null) throw new GameError('الإدخال ناقص.');

    let outcome;
    if (key === this.bomb.solution) {
      outcome = 'defused';
      me.status = 'defused';
      this.scores[team] += cfg.DEFUSE_POINTS;
    } else if (key === this.bomb.decoy) {
      outcome = 'fooled';
      me.status = 'fooled';
      const saboteurTeam = otherTeam(this.trueTeam);
      if (team !== saboteurTeam) this.scores[saboteurTeam] += cfg.FOOL_POINTS;
    } else {
      me.strikes += 1;
      outcome = me.strikes >= cfg.MAX_STRIKES ? 'out' : 'strike';
      if (outcome === 'out') me.status = 'out';
    }
    me.feedback = { outcome, at: now };

    if (outcome === 'defused') this.endRound(team, 'defused');
    else if (TEAMS.every(t => this.defusers[t].status !== 'racing')) this.endRound(null, 'all-out');
    return { outcome, strikes: me.strikes };
  }

  endRound(winner, reason) {
    if (this.phase !== 'race') return;
    for (const t of TEAMS) if (this.defusers[t].status === 'racing') this.defusers[t].status = winner ? 'beaten' : 'exploded';
    const saboteurTeam = otherTeam(this.trueTeam);
    this.result = {
      round: this.round,
      winner,
      reason,
      location: this.bomb.location,
      solutionText: this.bomb.solutionText,
      decoyText: this.bomb.decoyText,
      // the anonymity lifts only now
      reveal: this.hintOrder.map((team, i) => ({ label: 'AB'[i], team, truthful: team === this.trueTeam, text: this.hints[team] })),
      fooled: TEAMS.filter(t => this.defusers[t].status === 'fooled'),
      saboteurTeam,
      trueTeam: this.trueTeam,
      scores: { ...this.scores },
    };
    this.history.push(this.result);
    this.phase = 'result';
    this.phaseEndsAt = Date.now() + cfg.RESULT_MS;
    this.after(cfg.RESULT_MS, () => this.next());
  }

  // After the reveal: swap the guides and load a new bomb, or end the game.
  next() {
    if (this.phase !== 'result') throw new GameError('ما فيه شي تتخطاه.');
    if (this.round >= this.rounds) {
      clearTimeout(this.timer);
      this.phase = 'over';
      this.phaseEndsAt = null;
      return;
    }
    this.round += 1;
    this.trueTeam = otherTeam(this.trueTeam); // role reversal
    this.startRound();
  }

  /* ---------------- views ---------------- */

  roleOf(seat) {
    if (!seat) return null;
    const { team, kind } = SEAT_INFO[seat];
    if (kind === 'defuser') return 'defuser';
    if (!this.trueTeam) return 'guide';
    return team === this.trueTeam ? 'guide' : 'saboteur';
  }

  // What the TV shows, which is also the floor of what every phone sees.
  publicState() {
    const hintsOut = ['countdown', 'race', 'result', 'over'].includes(this.phase) && this.hintOrder;
    return {
      code: this.code,
      phase: this.phase,
      round: this.round,
      rounds: this.rounds,
      scores: this.scores,
      maxStrikes: cfg.MAX_STRIKES,
      hintMax: cfg.HINT_MAX,
      phaseEndsAt: this.phaseEndsAt,
      goAt: this.goAt,
      seats: Object.fromEntries(SEATS.map(s => {
        const p = this.players.get(this.seats[s]);
        return [s, p ? { name: p.name, connected: !!p.socketId } : null];
      })),
      lobby: [...this.players.values()].filter(p => !this.seatOf(p.id)).map(p => p.name),
      bomb: this.bomb && { location: this.bomb.location, type: this.bomb.type, layout: this.bomb.layout },
      hintsIn: TEAMS.filter(t => this.hints[t] !== null).length,
      // identical objects, A and B only: no team, no author, no timestamp
      hints: hintsOut ? this.hintOrder.map((team, i) => ({ label: 'AB'[i], text: this.hints[team] })) : null,
      defusers: this.defusers && Object.fromEntries(TEAMS.map(t => [t, { status: this.defusers[t].status, strikes: this.defusers[t].strikes }])),
      result: this.result,
      history: this.history,
    };
  }

  hostState() {
    return { ...this.publicState(), you: { host: true } };
  }

  stateFor(playerId) {
    const p = this.players.get(playerId);
    if (!p) return null;
    const seat = this.seatOf(playerId);
    const role = this.roleOf(seat);
    const team = seat ? SEAT_INFO[seat].team : null;
    const you = { id: p.id, name: p.name, seat, team, kind: seat ? SEAT_INFO[seat].kind : null, role };
    const live = this.bomb && ['hints', 'countdown', 'race', 'result'].includes(this.phase);
    if (live && role === 'guide') {
      you.brief = { location: this.bomb.location, story: this.bomb.story, module: this.bomb.type, steps: this.bomb.steps };
    } else if (live && role === 'saboteur') {
      you.keywords = this.bomb.keywords; // fragments only: no story, no location, no module name
    }
    if (role === 'guide' || role === 'saboteur') you.hint = this.hints[team];
    if (role === 'defuser' && this.defusers) {
      const d = this.defusers[team];
      you.defuser = { status: d.status, strikes: d.strikes, feedback: d.feedback };
    }
    return { ...this.publicState(), you };
  }
}

class RoomManager {
  constructor(onChange) {
    this.rooms = new Map();
    this.onChange = onChange;
  }

  create() {
    let code;
    do {
      code = Array.from({ length: 4 }, () => CODE_ALPHABET[randomInt(CODE_ALPHABET.length)]).join('');
    } while (this.rooms.has(code));
    const room = new Room(code, this.onChange);
    this.rooms.set(code, room);
    return room;
  }

  get(code) {
    return this.rooms.get(String(code || '').trim().toUpperCase()) || null;
  }

  // Drop rooms nobody is connected to and nothing has happened in for a while.
  sweep(now = Date.now()) {
    for (const [code, room] of this.rooms) {
      const anyone = room.hostSocket || [...room.players.values()].some(p => p.socketId);
      if (!anyone && now - room.lastActive > cfg.ROOM_IDLE_MS) {
        room.dispose();
        this.rooms.delete(code);
      }
    }
  }
}

module.exports = { Room, RoomManager, GameError, SEATS, SEAT_INFO, NO_HINT };

'use strict';
const { randomInt } = require('crypto');

const rand = n => randomInt(n);
const pick = list => list[rand(list.length)];
const shuffle = list => {
  for (let i = list.length - 1; i > 0; i--) {
    const j = rand(i + 1);
    [list[i], list[j]] = [list[j], list[i]];
  }
  return list;
};
// "1، 3 و 5"
const listWords = nums => (nums.length === 1 ? `${nums[0]}` : `${nums.slice(0, -1).join('، ')} و ${nums[nums.length - 1]}`);

// Keys stay Latin (the phones map them to a colour); names are what people read.
const COLORS = ['RED', 'BLUE', 'YELLOW', 'GREEN', 'WHITE', 'BLACK'];
const COLOR_AR = { RED: 'الأحمر', BLUE: 'الأزرق', YELLOW: 'الأصفر', GREEN: 'الأخضر', WHITE: 'الأبيض', BLACK: 'الأسود' };
const SWITCHES = 5;

const LOCATIONS = [
  {
    id: 'hotel', name: 'غرفة 302 بفندق الواحة', flavor: ['الميني بار', 'بطاقة الغرفة', 'خدمة الغرف'],
    story: 'واحد سجّل بالغرفة 302 باسم مزوّر وما طلع. عاملة النظافة لقت الجهاز مثبّت تحت السرير، يطنّ جنب صينية أكل ما أحد لمسها.',
  },
  {
    id: 'bank', name: 'قبو بنك الاتحاد', flavor: ['الخزنة', 'الصرّاف', 'صناديق الأمانات'],
    story: 'الكهرباء انقطعت عن القبو الساعة 2:14 الفجر. لما اشتغلت لمبات الطوارئ، كانت فيه شنطة حديد مربوطة على عجلة الخزنة، والحارس مختفي.',
  },
  {
    id: 'police', name: 'مكتب أدلة الشرطة', flavor: ['ختم الأحراز', 'الدولاب', 'ملف القضية'],
    story: 'الكرتون مسجّل «أجهزة مضبوطة، سليمة». ما كانت سليمة: العداد اشتغل أول ما الضابط قص ختم الأحراز.',
  },
  {
    id: 'hospital', name: 'غرفة تحكم المستشفى', flavor: ['المولّد', 'العناية المركزة', 'الشاشات'],
    story: 'كل الشاشات بغرفة التحكم تعرض نفس العداد. الجهاز موصول بالمولّد الاحتياطي اللي شاغل العناية المركزة.',
  },
  {
    id: 'metro', name: 'محطة مترو مهجورة', flavor: ['الرصيف', 'بوابة التذاكر', 'السكة'],
    story: 'آخر قطار مر من هنا سنة 1998. أحد رجع البارحة وخلّى صندوق تحت المقعد الحديدي جنب السكة.',
  },
  {
    id: 'stadium', name: 'كابينة البث بالملعب', flavor: ['لوحة النتائج', 'الكاميرا', 'المنصة'],
    story: 'ستين ألف مشجّع بالمدرجات. الجهاز ورا طاولة لوحة النتائج، وعرض نص الوقت يبدأ بعد دقايق.',
  },
];

// Each module returns what the TV and the defusers may see (layout), the solution and the decoy as comparable keys,
// the true guide's exact steps, and the saboteur's fragments. Every keyword comes from the decoy, so a saboteur who
// builds a hint from them writes the decoy, and a defuser who runs it is caught by the server as FOOLED.
const MODULES = {
  wires() {
    const colors = shuffle(COLORS.slice());
    const idx = () => shuffle([...colors.keys()]).slice(0, 2);
    const [a, b] = idx();
    let c, d;
    // A third of the time the decoy is the true pair reversed: the nastiest lie uses the right wires.
    do { [c, d] = rand(3) === 0 ? [b, a] : idx(); } while (c === a && d === b);
    const ar = i => COLOR_AR[colors[i]];
    return {
      type: 'wires',
      layout: { colors },
      solution: `${a},${b}`,
      decoy: `${c},${d}`,
      solutionText: `اقطع ${ar(a)} ثم ${ar(b)}`,
      decoyText: `اقطع ${ar(c)} ثم ${ar(d)}`,
      steps: [`اقطع السلك ${ar(a)} أول.`, `بعدها اقطع السلك ${ar(b)}.`, 'لا تلمس غيرهم.'],
      keywords: [`أول: ${ar(c)}`, `ثاني: ${ar(d)}`, 'اقطع'],
    };
  },
  keypad() {
    const four = () => String(1000 + rand(9000));
    const code = four();
    let decoy;
    // Half the time the decoy reuses the true digits in another order.
    do { decoy = rand(2) ? shuffle([...code]).join('') : four(); } while (decoy === code);
    return {
      type: 'keypad',
      layout: { length: 4 },
      solution: code,
      decoy,
      solutionText: `الكود ${code}`,
      decoyText: `الكود ${decoy}`,
      steps: [`اكتب ${code} على اللوحة.`, 'واضغط «إدخال».'],
      keywords: ['كود', `يبدأ ${decoy.slice(0, 2)}`, `ينتهي ${decoy.slice(2)}`],
    };
  },
  switches() {
    const pattern = () => shuffle([...Array(SWITCHES).keys()]).slice(0, 2 + rand(2)).sort((x, y) => x - y);
    const toKey = up => [...Array(SWITCHES).keys()].map(i => (up.includes(i) ? '1' : '0')).join('');
    const sol = pattern();
    let dec;
    do { dec = pattern(); } while (toKey(dec) === toKey(sol));
    const human = up => listWords(up.map(i => i + 1));
    return {
      type: 'switches',
      layout: { count: SWITCHES },
      solution: toKey(sol),
      decoy: toKey(dec),
      solutionText: `ارفع ${human(sol)}`,
      decoyText: `ارفع ${human(dec)}`,
      steps: [`ارفع المفاتيح ${human(sol)} لفوق.`, 'خلّ الباقي تحت.', 'واضغط «تسليح».'],
      keywords: [...dec.map(i => `مفتاح ${i + 1}`), 'فوق'],
    };
  },
};

function generateBomb(avoid = {}) {
  const locs = LOCATIONS.filter(l => l.id !== avoid.location);
  const types = Object.keys(MODULES).filter(t => t !== avoid.type);
  const loc = pick(locs);
  const mod = MODULES[pick(types)]();
  return {
    locationId: loc.id,
    location: loc.name,
    story: loc.story,
    ...mod,
    // one word of scenery among the fragments, so the fake can sound like it knows the room
    keywords: shuffle([...mod.keywords, pick(loc.flavor)]),
  };
}

// A defuser's raw input -> the same key format as solution/decoy, or null when it is malformed.
function normalizeSubmission(bomb, payload) {
  const p = payload && typeof payload === 'object' ? payload : {};
  switch (bomb.type) {
    case 'wires': {
      const cuts = Array.isArray(p.cuts) ? p.cuts.map(Number) : [];
      const n = bomb.layout.colors.length;
      if (cuts.length !== 2 || cuts[0] === cuts[1] || !cuts.every(i => Number.isInteger(i) && i >= 0 && i < n)) return null;
      return cuts.join(',');
    }
    case 'keypad':
      return typeof p.code === 'string' && /^\d{4}$/.test(p.code) ? p.code : null;
    case 'switches': {
      const s = p.switches;
      if (!Array.isArray(s) || s.length !== SWITCHES) return null;
      return s.map(v => (v ? '1' : '0')).join('');
    }
    default:
      return null;
  }
}

module.exports = { generateBomb, normalizeSubmission, LOCATIONS, MODULES, COLORS, COLOR_AR };

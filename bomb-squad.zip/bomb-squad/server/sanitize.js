'use strict';
const cfg = require('./config');

// Control characters, zero-width characters and bidi overrides. Bidi overrides matter here:
// they can visually reorder a hint on the TV, or make two hints look different in shape.
const INVISIBLE = /[\u0000-\u001F\u007F-\u009F\u00AD\u200B-\u200F\u202A-\u202E\u2060-\u2064\u2066-\u2069\uFEFF]/g;

function clean(input, max) {
  const s = String(input ?? '')
    .normalize('NFKC')
    .replace(/\s+/g, ' ') // newlines and tabs become spaces before the control-character pass could delete them
    .replace(INVISIBLE, '')
    .replace(/ {2,}/g, ' ')
    .trim();
  // Count code points, not UTF-16 units, so an emoji is one character, never half of one.
  return Array.from(s).slice(0, max).join('').trim();
}

const cleanHint = text => clean(text, cfg.HINT_MAX);
const cleanName = text => clean(text, cfg.NAME_MAX);

module.exports = { clean, cleanHint, cleanName };

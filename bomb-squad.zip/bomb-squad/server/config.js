'use strict';
// Every timing can be overridden from the environment, which is how the tests run a whole game in a few seconds.
const num = (name, fallback) => {
  const v = Number(process.env[name]);
  return Number.isFinite(v) && v >= 0 ? v : fallback;
};

module.exports = {
  PORT: num('PORT', 3000),
  ROUNDS: num('ROUNDS', 2),                 // each round swaps which guide tells the truth
  HINT_MS: num('HINT_MS', 60_000),          // guides read their brief and write a hint
  COUNTDOWN_MS: num('COUNTDOWN_MS', 3_000), // 3... 2... 1... GO, against the server clock
  RACE_MS: num('RACE_MS', 90_000),          // both defusers race
  RESULT_MS: num('RESULT_MS', 20_000),      // reveal screen; the host can skip it
  MAX_STRIKES: num('MAX_STRIKES', 3),
  DEFUSE_POINTS: 1,                         // first correct defusal
  FOOL_POINTS: 1,                           // the saboteur's team, when the other team's defuser runs the fake hint
  HINT_MAX: 50,
  NAME_MAX: 16,
  MAX_PLAYERS: 8,                           // four seats, a few spare phones in the lobby
  SUBMIT_COOLDOWN_MS: 250,                  // one defuser input per 250 ms
  ROOM_IDLE_MS: num('ROOM_IDLE_MS', 30 * 60_000),
  // Who holds the real brief in round 1. The spec has Team 1's guide start as the true guide;
  // 'random' hides even that from the table.
  FIRST_TRUE_TEAM: ['t1', 't2', 'random'].includes(process.env.FIRST_TRUE_TEAM) ? process.env.FIRST_TRUE_TEAM : 't1',
};

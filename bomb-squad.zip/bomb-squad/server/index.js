'use strict';
const path = require('path');
const http = require('http');
const express = require('express');
const { Server } = require('socket.io');
const cfg = require('./config');
const { RoomManager, GameError } = require('./rooms');

function createServer() {
  const app = express();
  const server = http.createServer(app);
  const io = new Server(server, { pingInterval: 10_000, pingTimeout: 8_000 });

  // Every recipient gets its own view: the TV the public one, each phone its own role on top.
  const push = room => {
    if (room.hostSocket) io.to(room.hostSocket).emit('state', room.hostState());
    for (const p of room.players.values()) if (p.socketId) io.to(p.socketId).emit('state', room.stateFor(p.id));
  };
  const manager = new RoomManager(push);
  const sweeper = setInterval(() => manager.sweep(), 60_000);
  sweeper.unref();
  server.on('close', () => clearInterval(sweeper));

  app.disable('x-powered-by');
  app.use(express.static(path.join(__dirname, '..', 'public'), { extensions: ['html'] }));
  app.get('/health', (req, res) => res.json({ ok: true, rooms: manager.rooms.size }));

  io.on('connection', socket => {
    // Wraps a handler: the last argument is the ack; game errors go back to the sender, anything else is logged.
    const on = (event, handler) => socket.on(event, (...args) => {
      const ack = typeof args[args.length - 1] === 'function' ? args.pop() : () => {};
      try {
        ack({ ok: true, ...(handler(...args) || {}) });
      } catch (err) {
        if (!(err instanceof GameError)) console.error(`[${event}]`, err);
        ack({ ok: false, error: err instanceof GameError ? err.message : 'صار خطأ بالسيرفر.' });
      }
    });
    const hostRoom = () => {
      const room = manager.get(socket.data.code);
      if (!room || !socket.data.host || room.hostSocket !== socket.id) throw new GameError('أنت مو مضيف غرفة.');
      return room;
    };
    const playerCtx = () => {
      const room = manager.get(socket.data.code);
      const player = room && room.players.get(socket.data.playerId);
      if (!player || player.socketId !== socket.id) throw new GameError('ادخل غرفة أول.');
      return { room, player };
    };
    const attachHost = room => {
      if (room.hostSocket && room.hostSocket !== socket.id) io.to(room.hostSocket).emit('kicked', 'انفتحت الغرفة على شاشة ثانية.');
      room.hostSocket = socket.id;
      socket.data = { code: room.code, host: true };
      room.changed();
      return { code: room.code, hostToken: room.hostToken };
    };

    // NTP-style: the client times the round trip and takes the server time at its midpoint.
    socket.on('clock:ping', (t0, ack) => typeof ack === 'function' && ack({ t0, server: Date.now() }));

    on('host:create', () => attachHost(manager.create()));
    on('host:resume', ({ code, hostToken } = {}) => {
      const room = manager.get(code);
      if (!room || room.hostToken !== hostToken) throw new GameError('هالغرفة ما عادت موجودة.');
      return attachHost(room);
    });
    on('host:start', () => { const r = hostRoom(); r.start(); r.changed(); });
    on('host:next', () => { const r = hostRoom(); r.next(); r.changed(); });
    on('host:kick', ({ seat } = {}) => {
      const r = hostRoom();
      const id = r.kick(seat);
      if (id) for (const [sid, s] of io.sockets.sockets) if (s.data.playerId === id) { s.emit('kicked', 'المضيف فضّى كرسيك.'); s.data = {}; }
      r.changed();
    });

    on('player:join', ({ code, name, playerId } = {}) => {
      const room = manager.get(code);
      if (!room) throw new GameError('ما فيه غرفة بهالرمز.');
      const known = playerId && room.players.get(playerId);
      if (known && known.socketId && known.socketId !== socket.id) io.to(known.socketId).emit('kicked', 'دخلت من صفحة ثانية.');
      const player = room.join(name, playerId, socket.id);
      socket.data = { code: room.code, playerId: player.id };
      room.changed();
      return { code: room.code, playerId: player.id };
    });
    on('player:seat', ({ seat } = {}) => { const { room, player } = playerCtx(); room.takeSeat(player.id, seat); room.changed(); });
    on('player:unseat', () => { const { room, player } = playerCtx(); room.leaveSeat(player.id); room.changed(); });
    on('guide:hint', ({ text } = {}) => {
      const { room, player } = playerCtx();
      const hint = room.submitHint(player.id, text);
      room.changed();
      return { hint };
    });
    on('defuser:submit', payload => {
      const { room, player } = playerCtx();
      const res = room.submitDefuse(player.id, payload);
      room.changed();
      return res;
    });

    socket.on('disconnect', () => {
      const room = manager.get(socket.data.code);
      if (!room) return;
      if (room.hostSocket === socket.id) room.hostSocket = null;
      room.disconnect(socket.id);
      room.changed();
    });
  });

  return { app, server, io, manager };
}

if (require.main === module) {
  const { server } = createServer();
  server.listen(cfg.PORT, () => console.log(`Bomb Squad on http://localhost:${cfg.PORT}  (TV: /host, phones: /play)`));
}

module.exports = { createServer };

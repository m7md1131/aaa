/** @type {import('tailwindcss').Config} */
// The palette and type of «جلسة»: the Saudi Founding Day colours on a light ground.
module.exports = {
  content: ['./public/**/*.{html,js}'],
  theme: {
    extend: {
      colors: {
        clarity: '#F4EADA', // الوضوح: page ground
        land: '#DEC9B2',    // الأرض
        auth: '#6B4E45',    // الأصالة: headings, the primary action
        resolve: '#231F20', // العزم: text, night
        ochre: '#BA7747',
        rose: '#D2988F',
        gold: '#F5D758',    // values and highlights, always with dark text
        red: '#A32B38',     // team 2, light text on it
        coral: '#E76A58',
        lilac: '#8A77A1',
        sage: '#8DAD73',
        teal: '#629BA6',    // team 1, dark text on it
        surface: '#FBF6EE',
        sunk: '#EFE3D1',
        muted: '#7A6259',
        mutedDk: '#DCCFC2',
        cream: '#EFE4CC',
        ink: '#201812',
        steel: '#3A3436',
      },
      fontFamily: {
        kufi: ['"Aref Ruqaa"', '"Reem Kufi"', 'serif'],
        display: ['"Reem Kufi"', '"IBM Plex Sans Arabic"', 'Tahoma', 'sans-serif'],
        body: ['"IBM Plex Sans Arabic"', 'Tahoma', '"Segoe UI"', 'sans-serif'],
        mono: ['ui-monospace', 'SFMono-Regular', 'monospace'],
      },
      keyframes: {
        shake: { '0%,100%': { transform: 'translateX(0)' }, '20%': { transform: 'translateX(-10px)' }, '40%': { transform: 'translateX(9px)' }, '60%': { transform: 'translateX(-6px)' }, '80%': { transform: 'translateX(4px)' } },
        pop: { '0%': { transform: 'scale(.6)', opacity: '0' }, '60%': { transform: 'scale(1.08)', opacity: '1' }, '100%': { transform: 'scale(1)' } },
      },
      animation: { shake: 'shake .45s ease', pop: 'pop .35s ease-out' },
    },
  },
  plugins: [],
};
